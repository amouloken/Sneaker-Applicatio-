package com.example.sneaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
